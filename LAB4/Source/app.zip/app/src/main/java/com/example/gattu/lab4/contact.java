package com.example.gattu.lab4;

/**
 * Created by gattu on 2/15/2017.
 */

public class contact {
    int id;
  //  String name;
    String email;
    String uname;
    String password;

  /*  public void setName(String name)
    {
        this.name = name;
    }

    public String getName()
    {
        return(this.name);
    }
*/
    public void setEmail(String email)
    {
        this.email = email;
    }

    public String getEmail()
    {
        return(this.email);
    }

    public void setUname(String uname)
    {
        this.uname = uname;
    }

    public String getUname()
    {
        return(this.uname);
    }


    public void setPassword(String password)
    {
        this.password = password;
    }

    public String getPassword()
    {
        return(this.password);
    }
}
