package com.example.gattu.lab4;

/**
 * Created by gattu on 2/11/2017.
 */
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.IOException;


public class Registration extends AppCompatActivity{


    String API_URL = "https://api.fullcontact.com/v2/person.json?";
    String API_KEY = "b29103a702edd6a";
    String sourceText;
    TextView outputTextView;
    Context mContext;

    DatabaseHelper helper = new DatabaseHelper(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registration);


    }


    public void login(View v)
    {
        EditText uname = (EditText) findViewById(R.id.txt_username);
        EditText pass = (EditText) findViewById(R.id.txt_Password);
        EditText email = (EditText) findViewById(R.id.txt_Email);
        TextView error = (TextView) findViewById(R.id.txt_error);
        TextView confirmPass = (TextView) findViewById(R.id.txt_Pass2);
        String userName = uname.getText().toString();
        String password = pass.getText().toString();
        String mailid = email.getText().toString();
        String confirm_password = confirmPass.getText().toString();
        if(password.length()<4)
        {
            error.setVisibility(View.VISIBLE);

        }
        else if(!password.equals(confirm_password)){

            Toast pass_error = Toast.makeText(Registration.this, "password don't match", Toast.LENGTH_SHORT);
            pass_error.show();
        }
        else {

            contact c = new contact();
            c.setUname(userName);
            c.setEmail(mailid);
            c.setPassword(password);

            helper.insertContact(c);

            Intent redirect = new Intent(Registration.this, Interaction.class);
            startActivity(redirect);
        }
    }


}
