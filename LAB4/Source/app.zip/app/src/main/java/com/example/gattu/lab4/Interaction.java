package com.example.gattu.lab4;


/**
 * Created by gattu on 2/11/2017.
 */

import android.Manifest;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;

import android.widget.TextView;

import android.content.pm.PackageManager;


public class Interaction extends AppCompatActivity {

    static  TextView placeTextView;
    static  TextView temperatureTextView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.weather);

        placeTextView = (TextView) findViewById(R.id.textView3);

        temperatureTextView = (TextView) findViewById(R.id.textView4);
        LocationManager mgr = (LocationManager)this.getSystemService(LOCATION_SERVICE);
        Criteria criteria = new Criteria();
        criteria.setPowerRequirement(Criteria.POWER_LOW);
        criteria.setAccuracy(Criteria.ACCURACY_FINE);
        criteria.setSpeedRequired(true);
        criteria.setAltitudeRequired(false);
        criteria.setBearingRequired(false);
        criteria.setCostAllowed(false);
        String best = mgr.getBestProvider(criteria, true);
    /*    //since you are using true as the second parameter, you will only get the best of providers which are enabled.
        Location location = mgr.getLastKnownLocation(best);

        LocationManager locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);

        String provider = locationManager.getBestProvider(new Criteria(), false); */

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }

       // String locationProvider = LocationManager.NETWORK_PROVIDER;
        Location location = mgr.getLastKnownLocation(best);

        Double lat = location.getLatitude();

        Double lng = location.getLongitude();

        DownloadTask task = new DownloadTask();


        task.execute("http://samples.openweathermap.org/data/2.5/weather?lat=" + String.valueOf(lat) +  "&lon="  + String.valueOf(lng) + " &appid =733f9c4efc63633ce2454c634f607b77");


    }

}
